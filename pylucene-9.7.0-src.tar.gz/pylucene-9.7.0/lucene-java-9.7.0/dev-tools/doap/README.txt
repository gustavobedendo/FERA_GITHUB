This folder contains the DOAP[1] file, which is parsed and displayed at https://projects.apache.org/project.html?lucene

Upon release, this file should be updated to include new release details.

NOTE: If this folder's contents are moved elsewhere, the website .htaccess
file will need to be updated.

[1] DOAP: https://github.com/edumbill/doap